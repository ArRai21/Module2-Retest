﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using ProductManagement.DataAccessLayer;
using ProductManagement.Entity;


namespace ProductManagement.BusinessLogicLayer
{
    public class ProductBL
    {
        public int AddProduct(Product p)
        {
            bool validate = false;
            int added=0;
            try
            {
                if (ValidateProduct(p))
                {
                    ProductDL pdl = new ProductDL();
                    added=pdl.AddProduct(p);
                }

    }
            catch (System.Exception)
            {

                throw;
            }
            return added;
            //return validate;
        }

        private bool ValidateProduct(Product p)
        {
           bool validate = true;
            try
            {
                Regex SrNo = new Regex("[0-9]{4}[-][0-9]{4}[-][0-9]{4}");

                if (!SrNo.Match(Convert.ToString(p.SerialNumber)).Success)
                { validate = false; }

                if(!(p.ProductType!="Mobile"|| p.ProductType !="Camera" || p.ProductType !="Laptop" || p.ProductType !="Appliances" || p.ProductType !="Accessories"))
                { validate = false; }

                if(p.Price==0)
                { validate = false; }
            }
            catch (System.Exception)
            {

                throw;
            }
            return validate;
        }

        public DataTable ListEmp()
        {
            ProductDL pdl = new ProductDL();
            return pdl.ListEmp();
        }
    }
}