﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityEntity
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Training_19Sep18_PuneEntities1 obj = new Training_19Sep18_PuneEntities1();
            Product p = new Product();
            DbSet<Product> ds = obj.Products;

            var sql = (from m in ds
                       select m.ProductType).Distinct();
            foreach(var item in sql)
            {
                comProduct.Items.Add(item);
            }

           


            
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    Training_19Sep18_PuneEntities1 obj = new Training_19Sep18_PuneEntities1();
        //    Product p = new Product();
        //    DbSet<Product> ds = obj.Products;

        //    var sql1 = from m in ds
        //               where m.ProductType == comProduct.SelectedValue.ToString()
        //               select m;
        //    dgProduct.ItemsSource = sql1.ToList();
        //}

        private void comProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Training_19Sep18_PuneEntities1 obj = new Training_19Sep18_PuneEntities1();
            Product p = new Product();
            DbSet<Product> ds = obj.Products;

            var sql1 = from m in ds
                       where m.ProductType == comProduct.SelectedValue.ToString()
                       select m;
            dgProduct.ItemsSource = sql1.ToList();
        }

        private void dgProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
    }

